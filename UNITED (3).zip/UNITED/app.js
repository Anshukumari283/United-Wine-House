
  document.addEventListener("DOMContentLoaded", function () {
    const saveBtn = document.querySelector(".save-btn");

    saveBtn.addEventListener("click", function () {
      // Hide the Country Modal
      const countryModalEl = document.getElementById("countryModal");
      const countryModal = bootstrap.Modal.getInstance(countryModalEl);
      countryModal.hide();

      // Show the Save Confirmation Modal
      const saveModalEl = document.getElementById("saveModal");
      const saveModal = new bootstrap.Modal(saveModalEl);
      saveModal.show();
    });
  });
